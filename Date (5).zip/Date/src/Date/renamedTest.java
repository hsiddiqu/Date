package Date;

import static org.junit.jupiter.api.Assertions.*;

import java.security.cert.CRL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.time.MonthDay;
import java.time.YearMonth;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;
import java.util.jar.Attributes.Name;

import javax.swing.JFormattedTextField.AbstractFormatter;
import javax.swing.text.DateFormatter;
import javax.xml.crypto.Data;

import org.junit.Assert;
import org.junit.jupiter.api.Test;




public class renamedTest {
	
	@Test
	public final void getMonth1_JanuaryTest() {
		String[] months = {"January", "February", "March", "April", "May", "June", "July", "August", "Septmeber", "October", "November", "December"};
		Date d = new Date();
		 
		int actual = d.getMonth();
		int expected = 1;
		assertEquals(expected, actual);
	}
	
	}
	
	
	


	
	
	
	  



       

     

	
	


