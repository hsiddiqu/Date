package Date;

import static org.junit.jupiter.api.Assertions.*;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.MonthDay;
import java.time.YearMonth;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;
import java.util.jar.Attributes.Name;

import javax.swing.JFormattedTextField.AbstractFormatter;
import javax.xml.crypto.Data;

import org.junit.Assert;
import org.junit.jupiter.api.Test;




class renamedTest {

	
	static int Day =1;
	static int Month = 1;
	int Year =  2023;
	private Object startDate;
	private int noOfMonths;
	private int current;
	@Test
	public void Year() {
		Date date = new Date(Day, Month, Year);
	    Assert.assertTrue(date.getYear() == Year);
		   
		    
		  }
	@Test
	 public void Month() {
		    Date date = new Date(Day, Month, Year);
		    Assert.assertTrue(date.getMonth() == Month);
		    
		  }
	 
	   
	 
	  
	 
	    
	   
	    
	    
	  
	  @Test
	  public void DateName(){
		  String testInput = "Date 1\2\2023";
		  Scanner testScanner = new Scanner(testInput);
		  Date notd = new Date(Day);
		    
		    Assert.assertEquals(23, notd.getDay());
		   
		    
		    
	 
	        // Printing the day, month, and year
	        System.out.println("day: " + Day);
	        System.out.println("month: " + Month);
	        System.out.println("year: " + Year);
	    }
	 public void Result(){
		 System.out.println("print out date");
	 }
	  }
	  



       

     

	
	


